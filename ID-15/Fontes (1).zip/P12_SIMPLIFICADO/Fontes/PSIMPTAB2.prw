#include 'protheus.ch'
#include 'parmtype.ch'
#include "Fileio.ch"

#DEFINE CRLF Chr(13)+Chr(10)

//---------------------------------------------------------------------------------------------------------------------------
/*/{Protheus.doc} IMPTAB 
@type function
@author Cesar Escobar	
@since 28/08/2017
@version 1.0
@param cTab, character, (Nome da tabela que ser� importada)
@param cArq, character, (Caminho e nome do arquivo com extens�o que ser� importado )
@param MV_XSQLLDR, caracter (parametro para armazenar os dados do comando sqlldr)
@return ${cTempTab}, ${Nome da tabela criada para armazenar os dados}
/*///---------------------------------------------------------------------------------------------------------------------------
User Function IMPTAB2(cTab, cArq)
	
	Local lRet 		:= .T.
	Local cIp		:= Alltrim(SuperGetMV('MV_XIMPIP',,''))
	Local cTempPath := U_GetTmpPath() + "migra\"
	Local cSqlLdr 	:= U_GetCnxLdr() //AllTrim(GetMv("MV_XSQLLDR"))
	Local cAliTab 	:= cTab
	Local cNomeArq  :=  cAliTab + DToS(DDatabase) + STRTRAN(TIME(),":","") 
	Local cArqCTL   := cTempPath + cNomeArq + ".ctl"
	Local cArqBAT   := cTempPath + cNomeArq + ".bat"
	Local nHdlCTL   := 0
	Local nHdlBAT   := 0
	Local cTempTab  := ""
	Local cSequence := ""
	Local cQry      := ""
    Local nRetQry   := 0
	
	If !ExistDir( cTempPath )
		MakeDir(cTempPath)
	EndIf
	
	If Empty(cSqlLdr)
	   return .F.
	Endif
	
	
	//cAliTab := Substr(cTab,1,3)

	DbSelectArea(cAliTab)
	
	cTempTab := "Z" + cTab 
	cSequence := "RECNO" + cAliTab
	
	cQry := "CREATE TABLE " + cTempTab
	cQry += " (LINHAO VARCHAR2(4000 BYTE),NUMLINHA NUMBER(10))"
	
	If !MsFile(cTempTab)
		nRetQry := TCSqlExec(cQry)
	Else
		nRetQry := TCSqlExec("TRUNCATE TABLE " + cTempTab)
	EndIf

    cMSGerr := tcsqlerror()
    
    If (nRetQry < 0)
       MsgStop("Erro durante a cria��o da tabela tempor�ria!"+CRLF+cMSGerr)
       return ""
    Endif
	
	TCSqlExec("DROP SEQUENCE " + cSequence)
	TCSqlExec("CREATE SEQUENCE " + cSequence + " START WITH 0 INCREMENT BY 1 MINVALUE 0")
	
	nHdlCTL := FCREATE(cArqCTL, 0)
	
	If nHdlCTL >= 0
		FWRITE( nHdlCTL, "load data" + CRLF)
		FWRITE( nHdlCTL, "infile '" + cIp + cArq + "' " + '"str ' +  "'\r\n'" + '"' + CRLF)
		FWRITE( nHdlCTL, "append" + CRLF)
		FWRITE( nHdlCTL, "into table " + cTempTab + CRLF)
		FWRITE( nHdlCTL, "fields terminated by '\r\n'" + CRLF)
		FWRITE( nHdlCTL, "trailing nullcols" + CRLF)
		FWRITE( nHdlCTL, "(" + CRLF)
		FWRITE( nHdlCTL, "LINHAO CHAR(4000)," + CRLF)
		FWRITE( nHdlCTL, 'NUMLINHA "' + cSequence + '.NEXTVAL"' + CRLF)
		FWRITE( nHdlCTL, ")" + CRLF)
				
		nHdlBAT := FCREATE(cArqBAT, 0)
		If nHdlBAT >= 0
		   FWRITE(nHdlBAT, "@echo off" + CRLF)
		   //FWRITE(nHdlBAT, 'attrib +h "'+cArqBAT+'"' + CRLF)
		   FWRITE(nHdlBAT, cSqlLdr + " CONTROL=" + cArqCTL + "  ERRORS=999999999 skip=0" + CRLF)
		   //FWRITE(nHdlBAT, 'del /Q "'+cArqBAT+'"' + CRLF)
		   FCLOSE(nHdlBAT)
		Else
			/*Aviso("N�o criou o arquivo BAT")*/	
		EndIf
		
		FCLOSE(nHdlCTL)
	
	Else
		/*Aviso("N�o criou o arquivo CTL")*/
		lRet := .F.
	EndIf
	
	If lRet
		If WaitRun(cArqBAT, 1) == 0
		   lRet := Before_Exec(Right(cTempTab,3))
		   If ! lRet
		      cTempTab := ""
		   Endif
		EndIf 
	EndIf
	
    If File(cArqBAT)
       //ferase(cArqBAT)
    Endif
	
return cTempTab

*********************************
Static Function SetDelim(cTabTmp)
*********************************
   Local cCmd1 := "UPDATE {1} SET LINHAO = REPLACE(LINHAO,';',',') WHERE ( INSTR(LINHAO,CHR(165)) > 0) AND ( INSTR(LINHAO,';') > 0)"
   Local cCmd2 := "UPDATE {1} SET LINHAO = REPLACE(REPLACE(LINHAO,CHR(34)||CHR(165)||CHR(34),';'),CHR(34),'') WHERE ( INSTR(LINHAO,CHR(165)) > 0)"
   Local cCmd3 := "UPDATE {1} SET LINHAO = REPLACE(LINHAO,CHR(165),';') WHERE ( INSTR(LINHAO,CHR(165)) > 0)"
   
   cCmd1 := StrTran(cCmd1,"{1}",cTabTmp)
   cCmd2 := StrTran(cCmd2,"{1}",cTabTmp)
   cCmd3 := StrTran(cCmd3,"{1}",cTabTmp)
   
   If TcSqlExec(cCmd1) < 0
      MsgAlert("Erro na Constru��o da senten�a sql (cmd1): " + CHR(13) + TCSqlError())
      Return .F.
   Endif
   
   If TcSqlExec(cCmd2) < 0
      MsgAlert("Erro na Constru��o da senten�a sql (cmd2): " + CHR(13) + TCSqlError())
      Return .F.
   Endif     

   If TcSqlExec(cCmd3) < 0
      MsgAlert("Erro na Constru��o da senten�a sql (cmd3): " + CHR(13) + TCSqlError())
      Return .F.
   Endif     
        
Return .T.     
   
************************************   
Static Function Before_Exec(cDestin)
************************************
   Local lRet      := .T.
   Local cFunction := "U_EBEx"+AllTrim(cDestin)
   
   If FindFunction(cFunction)
      lRet := &(cFunction + StrTran('("{1}")',"{1}",cDestin) )
   Endif
   
return lRet
   
***********************************
Static Function After_Exec(cDestin)
***********************************
   Local lRet      := .T.
   Local cFunction := "U_EAEx"+AllTrim(cDestin)
   
   If FindFunction(cFunction)
      lRet := &(cFunction+'()')
   Endif
   
return lRet
   