#include 'protheus.ch'
#include 'parmtype.ch'


/*/{Protheus.doc} F240AFIL
//TODO -->> PE para filtrar os t�tulos a pagar a partir da chamada de Border�s(chamada dentro do FINA750 - fun��es do contas a pagar)
Deve considerar os par�metros FS_CODGRPO e FS_CODUSER

@author Alexandre Felicio 
@since 15/12/2019
@version 12.1.17
@return ${return}, ${return_description}

@type function
/*/
user function F240AFIL()
Local _cCusr  := RetCodUsr()
Local _aGrup  := UsrRetGrp(RetCodUsr())
Local _cCodG  := GetMV("FS_CODGRPO")
Local _cCodU  := GetMV("FS_CODUSER")
Local _cFilP  := PARAMIXB[1]
Local _cExprF := ''
Local  cAlias74    := GetNextAlias()
Local _cQuery      := ''
Local _nM     := ''
Local _cOkPar := ''
	
	For _nM := 1 to Len(_aGrup)		
	   _cOkPar := IIf(_aGrup[_nM] $ _cCodG,'S','')	   
	   If _cOkPar == 'S'
	       Exit  
	   endif
	Next
	
	IF !(_cOkPar == 'S')  .and. !( _cCusr $ _cCodU) 
	     
            Iif(Select((cAlias74)) > 0, (cAlias74)->(DbCloseArea()),)						   
								
			_cQuery := " SELECT A2_COD||A2_LOJA FORNECLJ "     
			_cQuery += " FROM  " + RetSqlName("SA2") 
			_cQuery += " WHERE  A2_FILIAL  = '" + xFilial( "SA2" ) + "'" 
			_cQuery += " and D_E_L_E_T_ = ' ' " 
			_cQuery += " AND A2_XAUTORI = 'S' "
			
			dbUseArea(.T. , "TOPCONN" , TcGenQry(,,_cQuery) , (cAlias74) , .T. , .T.)

			(cAlias74)->(DbGoTop())
			While !(cAlias74)->(Eof())
					
				_cExprF += " and E2_FORNECE||E2_LOJA <> '" + 	(cAlias74)->FORNECLJ + "'" 	
						
				(cAlias74)->(DbSkip())
			EndDo
			
						 
			(cAlias74)->(DbCloseArea())
	endif 
		
	IF !Empty(_cExprF)	
	   _cFilP   := _cFilP + _cExprF
	endif  
	
return(_cFilP)	
